
#!/usr/bin/env python3
"""Create and run two pressure-driven OpenFOAM cases."""

import re
import shutil
import subprocess
import sys
from pathlib import Path

WATER_PRESSURE_PA = 14500

SCENARIOS = (
    {
        "label": "water14p5kPa_oil20kPa",
        "water_pressure": 14500,
        "oil_pressure": 20000,
    },
    {
        "label": "water14p5kPa_oil30kPa",
        "water_pressure": 14500,
        "oil_pressure": 30000,
    },
)

REQUIRED_PATCHES = (
    "inlet_water",
    "inlet_oil",
    "outlet",
    "flow_channel",
)


def patch_pattern(patch_name):
    """Match both 'patch {' and 'patch\\n{' OpenFOAM formats."""
    return re.compile(
        rf"(?m)^[ \t]*{re.escape(patch_name)}[ \t]*"
        rf"(?:\r?\n[ \t]*)?\{{"
    )


def extract_braced_block(text, patch_name):
    """Extract one patch dictionary using brace matching."""
    match = patch_pattern(patch_name).search(text)

    if not match:
        raise RuntimeError(
            f"境界条件ファイルにパッチ '{patch_name}' がありません。"
        )

    open_brace = text.find("{", match.start())
    depth = 0

    for index in range(open_brace, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                end = index + 1
                return match.start(), end, text[match.start():end]

    raise RuntimeError(
        f"パッチ '{patch_name}' の括弧が正しく閉じられていません。"
    )


def run_logged(command, cwd, log_name):
    """Run a command and save its output to a log file."""
    log_path = cwd / log_name
    print(f"\n実行: {' '.join(command)}")
    print(f"ログ: {log_path}")

    with log_path.open("w", encoding="utf-8") as log:
        result = subprocess.run(
            command,
            cwd=cwd,
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )

    if result.returncode != 0:
        lines = log_path.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()
        print("\n--- ログ末尾 ---")
        print("\n".join(lines[-40:]))
        raise RuntimeError(
            f"{command[0]} が終了コード {result.returncode} "
            "で失敗しました。"
        )


def get_next_run_number(cases_dir):
    """Find the next unused run number."""
    max_num = 0
    pattern = re.compile(r"^run_(\d+)(?:_|$)")

    for path in cases_dir.glob("run_*"):
        if path.is_dir():
            match = pattern.match(path.name)
            if match:
                max_num = max(max_num, int(match.group(1)))

    return max_num + 1


def validate_field_patches(case_dir):
    """Check all required boundary names in all three fields."""
    for field_name in ("U", "p_rgh", "alpha.water"):
        field_path = case_dir / "0.orig" / field_name

        if not field_path.is_file():
            raise FileNotFoundError(
                f"必要な初期条件ファイルがありません: {field_path}"
            )

        text = field_path.read_text(encoding="utf-8")

        for patch_name in REQUIRED_PATCHES:
            if not patch_pattern(patch_name).search(text):
                raise RuntimeError(
                    f"{field_path} に '{patch_name}' がありません。"
                    "境界名とメッシュのパッチ名を確認してください。"
                )


def set_patch_pressure(p_rgh_path, patch_name, pressure_pa):
    """Set the fixedValue pressure for one boundary patch."""
    text = p_rgh_path.read_text(encoding="utf-8")
    start, end, block = extract_braced_block(text, patch_name)

    if not re.search(r"\btype\s+fixedValue\s*;", block):
        raise RuntimeError(
            f"{p_rgh_path}: {patch_name} が fixedValue ではありません。"
        )

    new_block, count = re.subn(
        r"(\bvalue\s+uniform\s+)[^;]+;",
        lambda m: m.group(1) + f"{pressure_pa};",
        block,
        count=1,
    )

    if count != 1:
        raise RuntimeError(
            f"{p_rgh_path}: {patch_name} の value uniform を"
            "更新できませんでした。"
        )

    text = text[:start] + new_block + text[end:]
    p_rgh_path.write_text(text, encoding="utf-8")


def prepare_case(calc_base, mesh_source, run_dir,
                 water_pressure, oil_pressure):
    """Copy the template, set pressures, and initialize the case."""
    print("\n" + "=" * 60)
    print(f"Case: {run_dir.name}")
    print(f"水入口: {water_pressure} Pa")
    print(f"油入口: {oil_pressure} Pa")
    print("出口: 0 Pa")
    print("=" * 60)

    if run_dir.exists():
        raise FileExistsError(
            f"Caseディレクトリが既に存在します: {run_dir}"
        )

    print("\n[1/5] 計算用ディレクトリを作成")
    shutil.copytree(calc_base, run_dir)

    print("[2/5] メッシュをコピー")
    target_mesh = run_dir / "constant" / "polyMesh"
    if target_mesh.exists():
        shutil.rmtree(target_mesh)
    shutil.copytree(mesh_source, target_mesh)

    print("[3/5] 境界条件ファイルを確認")
    validate_field_patches(run_dir)

    print("[4/5] 入口圧力を設定")
    p_rgh_path = run_dir / "0.orig" / "p_rgh"
    set_patch_pressure(p_rgh_path, "inlet_water", water_pressure)
    set_patch_pressure(p_rgh_path, "inlet_oil", oil_pressure)

    text = p_rgh_path.read_text(encoding="utf-8")
    _, _, outlet_block = extract_braced_block(text, "outlet")

    if not re.search(r"\btype\s+fixedValue\s*;", outlet_block):
        raise RuntimeError("p_rgh の outlet は fixedValue ではありません。")

    if not re.search(
        r"\bvalue\s+uniform\s+0(?:\.0*)?\s*;", outlet_block
    ):
        raise RuntimeError("p_rgh の outlet 圧力が 0 Pa ではありません。")

    print("[5/5] 初期場を作成")
    time_zero = run_dir / "0"
    if time_zero.exists():
        shutil.rmtree(time_zero)
    shutil.copytree(run_dir / "0.orig", time_zero)

    run_logged(["setFields"], run_dir, "log.setFields")
    print(f"\n[OK] {run_dir.name} の準備完了")


def launch_solver(run_dir):
    """Launch interFoam in the background."""
    log_path = run_dir / "log.interFoam"

    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(
            ["interFoam"],
            cwd=run_dir,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )

    (run_dir / "interFoam.pid").write_text(
        f"{process.pid}\n", encoding="utf-8"
    )

    print(f"[起動] {run_dir.name}: PID={process.pid}")
    print(f"ログ: {log_path}")


def main():
    project_root = Path(__file__).resolve().parent.parent
    cases_dir = project_root / "cases"
    calc_base = cases_dir / "calc_base"
    mesh_source = (
        cases_dir / "mesh_base" / "constant" / "polyMesh"
    )

    if not calc_base.is_dir():
        raise FileNotFoundError(f"テンプレートがありません: {calc_base}")

    if not (mesh_source / "boundary").is_file():
        raise FileNotFoundError(f"メッシュがありません: {mesh_source}")

    run_number = get_next_run_number(cases_dir)
    run_dirs = []

    print("\n水入口: 14.5 kPa / 出口: 0 Pa")
    print("油入口: 20 kPa と 30 kPa")
    print("2ケースを準備後、バックグラウンドで実行します。")

    # Prepare both cases before starting either solver.
    for index, scenario in enumerate(SCENARIOS):
        run_dir = cases_dir / (
            f"run_{run_number + index:03d}_{scenario['label']}"
        )

        prepare_case(
            calc_base,
            mesh_source,
            run_dir,
            scenario["water_pressure"],
            scenario["oil_pressure"],
        )
        run_dirs.append(run_dir)

    print("\n両ケースの準備が完了しました。計算を起動します。")

    for run_dir in run_dirs:
        launch_solver(run_dir)

    print("\n起動処理が完了しました。")
    for run_dir in run_dirs:
        print(f"  {run_dir.name}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\n[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)
